const resultElement = document.getElementById("result")
const lengthElement = document.getElementById("length")
const upperCaseElement= document.getElementById("uppercase")
const lowerCaseElement= document.getElementById("lowercase")
const numbersElement = document.getElementById("number")
const symbolsElement = document.getElementById("symbols")
const generateElement = document.getElementById("generate")
const clipBoardElement = document.getElementById("clipboard")

// The uppercase letter get for random by using this function

function getRandomUpper(){

    return String.fromCharCode(Math.floor(Math.random() *26) + 65)
   
}

//  The lowercase letter get for random by using this function

function getRandomLower(){

    return String.fromCharCode(Math.floor(Math.random() *26) + 97);
}

//  get number for random by using this function

function getRandomNumber(){

    return String.fromCharCode(Math.floor(Math.random() *10) + 48);
}
//  get symbolsbfor random by using this function

function getRandomSymbols(){

    // creating a variable the symbols are stored in string type that is used to get the randon symbols
   
    const symbols = "!@#$%~&(){}\?[]=/><,."
     return symbols[Math.floor(Math.random()*symbols.length)]
}

// creating an object for randomFunction after that given key and value

const randomFunction = {
    lower : getRandomLower,
    upper : getRandomUpper,
    number : getRandomNumber,
    symbol: getRandomSymbols,
};

//  To check the key and values by using "console.log(randomFunction.lower)"

// when i click on generate after check the check the box ticked or not by using eventListener function

generateElement.addEventListener("click", () =>{
    // the checkbox ticked or unticked for checking console.log(upperCaseElement.checked);
   const hasLower = lowerCaseElement.checked;
   const hasUpper = upperCaseElement.checked;
    const hasNumber = numbersElement.checked;
    const hasSymbol = symbolsElement.checked;
    const length = lengthElement.value;
console.log(hasLower,hasUpper,hasNumber,hasSymbol,length)
 //   here also checking for using console.log(lengthElement.value);
  resultElement.innerText = generatePassword(
        hasLower,
        hasUpper,
        hasNumber,
        hasSymbol,
        length
    ) ;
});
// generatepassword function create to put in parameter of values

function generatePassword (lower,upper,number,symbol,length){
     let generatedPassword = "";
     const typesCount = lower + upper + number + symbol;
    const typesArr = [{ lower},{upper},{number},{symbol}].filter(
        (item) => Object.values(item)[0]
    );
    console.log(typesArr);
    if(typesCount === 0 ) {
        return "";
    }
    for (let i=0;i < length; i +=typesCount) {
        typesArr.forEach((type) =>{
            const functionName = Object.keys(type)[0];
            console.log(functionName);
            generatedPassword +=randomFunction[functionName]();
        } )
    }
    console.log(generatedPassword)
    const finalPassword = generatedPassword.slice(0,length)
    return finalPassword;
 }

 clipBoardElement.addEventListener('click', () =>{
    const textarea = document.createElement("textarea");
    const Password = resultElement.innerText;
    if (!Password){
        return "";
    }
    textarea.value = Password;
    document.body.appendChild(textarea);
    textarea.select();
    document.execCommand("copy");
    textarea.remove();
    alert("Password copied to clipboard")
 });
